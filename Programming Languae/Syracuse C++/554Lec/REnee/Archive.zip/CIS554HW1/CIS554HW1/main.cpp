//CIS554 HW1
//Due: 11:59PM, Friday (9/14)

#include <iostream>
using namespace std;

class node {
public:
    int value;
    node * next;
    node * previous;
    node(int i) { value = i; next = previous = nullptr; }
    node() { next = previous = nullptr; }
};

class doubly_linked_list {
public:
    node * head;
    node * tail;
    doubly_linked_list() { head = tail = nullptr; }
    void make_random_list(int m, int n);
    void print_forward();
    void print_backward();
    
    //inplement the following member functions:
    
    void remove_one(int k); //remvoe the first node with value k
    void remove_all(int k); //remove all nodes with value k
    void reverse();//reverse the order of the list
    void sort(); //sort the nodes in ascending order
    //void quickSort(node *l, node *h);
    void insert(int k); //insert a node to an already sorted list
};

void doubly_linked_list::remove_one(int k) {
    if(head==tail&&head==nullptr) return;
    if (head==tail&&head->value==k) {head=tail=nullptr; return;}
    node * a = head;
    while(a!=nullptr){
        if (a->value==k) {
            if (a==head) {
                head = a->next;
                delete a;
                head->previous = nullptr;
                return;
            }
            if (a == tail) {
                a->previous->next = nullptr;
                tail = a->previous;
                delete a;
                return;
            }
            else {
                a->previous->next = a->next;
                a->next->previous = a->previous;
                delete a;
                return;
            }
        }
        else a=a->next;
    }
}

void doubly_linked_list::remove_all(int k) {
    if(head==tail&&head==nullptr) return;
    if (head==tail&&head->value==k) {head=tail=nullptr; return;}
    node * a = head;
    while(a!=nullptr){
        if (a->value==k) {
            if (a==head) {
                head = a->next;
                delete a;
                head->previous = nullptr;
                a=head;
            }
            else if (a == tail) {
                a->previous->next = nullptr;
                tail = a->previous;
                delete a;
                return;
            }
            else {
                node *b = a->next;
                a->previous->next = a->next;
                a->next->previous = a->previous;
                delete a;
                a=b;
            }
        }
        else a=a->next;
    }
}

void doubly_linked_list::reverse() {
    node *a = head;
    node *b;
    if(head==tail) return;
    while (a!=nullptr) {
        b=a->next;
        a->next = a->previous;
        a->previous = b;
        a = b;
    }
    b = head;
    head = tail;
    tail = b;
}



void doubly_linked_list::sort() {
    node * a = head;
    node * b;
    node * c;
    if (head==tail) return;
    while(a!=nullptr) {
        b = a->next;
        c = a;
        while (b!=nullptr) {
            if (b->value<c->value) {
                c=b;
            }
            b=b->next;
        }
        if (c!=a){
        int temp = c->value;
        c->value = a->value;
        a->value = temp;
        }
        a=a->next;
    }
    
}


void doubly_linked_list::insert(int k) {
    node * a = head;
    node * knode = new node(k);
    if(head==tail&&head==nullptr)  {head=new node(k); tail = head;return;}
    while (a!=nullptr) {
        if(k<=a->value) {
            
            if (a==head) {
                knode->previous = a->previous;
                knode-> next = a;
                a->previous = knode;
                head = knode;
            }
            else if (a==tail){
                knode->previous = a->previous;
                knode-> next = a;
                a->previous = knode;
                
            }
            else {
                knode->previous = a->previous;
                a->previous->next = knode;
                knode-> next = a;
                a->previous = knode;
            }
            return;
        }
        else
            a = a->next;
    }
    tail->next = knode;
    knode->previous=tail;
    tail=knode;
}

void doubly_linked_list:: make_random_list(int m, int n) {
    
    for (int i = 0; i < m; i++) {
        node * p1 = new node(rand() % n);
        p1->previous = tail;
        if (tail != nullptr) tail->next = p1;
        tail= p1;
        if (head == nullptr) head = p1;
    }
}

void doubly_linked_list::print_forward() {
    cout << endl;
    node * p1 = head;
    while (p1 != nullptr) {
        cout << p1->value << " ";
        p1 = p1->next;
    }
}

void doubly_linked_list::print_backward() {
    cout << endl;
    node * p1 = tail;
    while (p1 != nullptr) {
        cout << p1->value << " ";
        p1 = p1->previous;
    }
}

int main() {
//    doubly_linked_list d2;
//    for (int i = 0; i < 0; i++) {
//        node * p1 = new node(rand() % 10);
//        p1->previous = d2.tail;
//        if (d2.tail != nullptr) d2.tail->next = p1;
//        d2.tail= p1;
//        if (d2.head == nullptr) d2.head = p1;
//    }
//    //cout << "d2 tail " << d2.tail->value << endl;
//    //d2.remove_one(1);
////    d2.print_forward();
////    d2.print_backward();
////    cout << d2.head->value<<endl;
////    cout << d2.tail->value<<endl;
//    cout << "ori";
//    d2.print_forward();
//    d2.print_backward();
//    d2.insert(7);
//    cout << "insert";
//    d2.print_forward();
//    d2.print_backward();
//    cout << "ahh";
//    //d2.print_backward();
    
    
    cout << "test";
    
    doubly_linked_list d1;
    d1.make_random_list(30, 10);
    d1.print_forward();
    d1.print_backward();
    cout << "q";
    
    d1.reverse();
    d1.print_forward();
    d1.print_backward();
    cout << "w";
    
    d1.remove_one(7);
    d1.remove_one(8);
    d1.print_forward();
    d1.print_backward();
    cout << "e";
    
    
    
    d1.remove_all(9);
    d1.print_forward();
    d1.print_backward();
    cout << "r";
    
    d1.sort();
    d1.print_forward();
    d1.print_backward();
    cout << "sss";
    
    d1.insert(4);
    d1.insert(9);
    d1.insert(0);
    d1.print_forward();
    d1.print_backward();
    
    
    getchar();
    getchar();
    return 0;
}
