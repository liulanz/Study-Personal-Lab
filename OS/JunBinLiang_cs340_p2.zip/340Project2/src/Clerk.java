import java.util.*;
import java.util.concurrent.Semaphore;
public class Clerk implements Runnable {
	int id=-1;
	static Queue<Integer>seats=new LinkedList<>();
	static Semaphore sem;
	public Clerk(int id) {
		this.id=id;
		//System.out.println(seats);
	}
	@Override
	//After all passengers receive their boarding pass, the check-in clerks are done for the day (they terminate)
	public void run() {
		// TODO Auto-generated method stub
		try {
			Clerk.sem.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		msg(("Clerk "+this.id+"  finish its job"+"  "));
		Clerk.sem.release();
		return;
	}
	
	public void msg(String m) {
		 System.out.println("["+(System.currentTimeMillis()-Main.time)+"] "+": "+m);
	}
	
	private Passenger get() {
		return null;
	}

}
