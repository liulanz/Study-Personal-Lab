import java.util.*;
import java.util.concurrent.Semaphore;
public class Main {
	static int numPassengers=30;
	static int counter=2;
	public static long time = System.currentTimeMillis();
	public static void main(String[] args) throws InterruptedException {		
		//reading input from the command line
		if(args.length!=0)numPassengers=Integer.parseInt(args[0]);
		List<Thread>clerkpool=new ArrayList<>();
		List<Thread>passengerpool=new ArrayList<>();
		msg("Run");
		
		int zones=numPassengers/10;
		Passenger.map=new HashMap<>();
		Passenger.zonesem=new Semaphore[zones+1];
		Passenger.passngersem=new Semaphore[numPassengers+1];
		for(int i=0;i<=numPassengers;i++) {
			Passenger.passngersem[i]=new Semaphore(1);
			Passenger.passngersem[i].acquire();
		}
		for(int i=0;i<=zones;i++) {
			Passenger.zonesem[i]=new Semaphore(1);
			Passenger.zonesem[i].acquire();
		}
		
		Clerk.sem=new Semaphore(1);
		Clerk.sem.acquire();//lock the clerk semaphore
		Attendant.sem=new Semaphore(1);
		Attendant.sem.acquire();
		Attendant.list=new ArrayList<>();
		
		//all available seats, in random order by using hashset
		Set<Integer>seats=new HashSet<>();
		for(int i=1;i<=numPassengers;i++)seats.add(i);
		for(Integer i:seats)Clerk.seats.add(i);

		//2 clerk counter
		for(int i=0;i<counter;i++) {
			clerkpool.add(new Thread(new Clerk(i)));
		}
		for(Thread t:clerkpool) {
			t.start();
		}
		
		//passenger
		for(int i=0;i<numPassengers;i++) {
			Thread t=new Passenger(i);
			passengerpool.add(t);
		}
		for(Thread t:passengerpool) {
			t.start();
		}
		
		Thread a=new Attendant(numPassengers);
		a.start();
		//all threads should join to the main thread
		try {
			a.join();
			for(Thread t:passengerpool)t.join();
			for(Thread t:clerkpool)t.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		msg("The flight attendant cleans the aircraft and is the last to leave after all the passengers.");
	}
	
	
	
	public static String getName() {
		return "Main Thread";
	}
	
	public static void msg(String m) {
		 System.out.println("["+(System.currentTimeMillis()-time)+"] "+getName()+": "+m);
	}

}
