import java.util.*;
import java.util.concurrent.Semaphore;
public class Passenger extends Thread {
	int id=-1;
	int seat=-1;
	int line=-1;
	Random rand=new Random();
	Thread t;
	static Map<Integer,Integer>map;
	static Semaphore sem;
	static Semaphore zonesem[];
	static Semaphore passngersem[];
	public Passenger(int id) {
		this.id=id;
		if(Passenger.sem==null) {
			Passenger.sem=new Semaphore(1);
		}
	}
	
	@Override
	public void run() {
		try {
			Thread.sleep(rand.nextInt(1500)); //randomly arrive
			//generate a seat
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		msg(("Passenger "+id+"  arrive and go straight to the check-in counter "));
		line=rand.nextInt(100)%2;
		msg(("Passenger "+id+"  at line "+line));
		
				
		//receiving
		try {
			Passenger.sem.acquire();
			seat=Clerk.seats.poll();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(Clerk.seats.size()==0)Clerk.sem.release();
		Passenger.sem.release();
		msg(("Passenger "+id+" get a seat number "+seat+"  is zone :"+getZone()+" and rushing"));
		if(!map.containsKey(getZone()))map.put(getZone(),0);
		map.put(getZone(),map.get(getZone())+1);
		rushing();
		
		int zone=getZone();
		try {
			Passenger.zonesem[zone].acquire();
			msg(("Passenger "+id+"  with seat"+seat+" zone"+getZone()+"  stwo belonging"));
			msg(("Passenger "+id+"  with seat"+seat+" zone"+getZone()+"  scaning and enter the plane"));
			map.put(zone,map.get(zone)-1);
			if(map.get(zone)==0)Passenger.zonesem[zone+1].release(); //all this zone is check
			Passenger.zonesem[zone].release();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Passenger.passngersem[seat-1].acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		msg("Passenger "+id+" seatNum"+seat+" wake up and leave the plane");
		Passenger.passngersem[seat].release();
		return;
	}
	
	private void rushing() {
		int oldp=this.getPriority();
		this.setPriority(oldp+1);
		try {
			Thread.sleep(rand.nextInt(1500));
		} catch (InterruptedException e) {
				// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.setPriority(oldp);
		msg(("Passenger "+id+"  with seat"+seat+"  arrive the gate"));
		Attendant.list.add(id);
		if(Attendant.list.size()==Main.numPassengers)Attendant.sem.release();
		
	}
	
	private void finalsleep() {
		try {
			msg("Passenger"+id+" long sleep");
			Thread.sleep(10000000);
		} catch (InterruptedException e) {
			msg("Passenger "+id+" seatNum"+seat+" wake up and leave the plane");
		}
	}
	
	public int getZone() {
		return (seat-1)/10;
	}
	
	public String toString() {
		return "[P "+seat+"]";
	}
	
	public void msg(String m) {
		 System.out.println("["+(System.currentTimeMillis()-Main.time)+"] "+": "+m);
	}

}
