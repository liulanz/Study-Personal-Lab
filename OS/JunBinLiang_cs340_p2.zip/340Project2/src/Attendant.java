import java.util.*;
import java.util.concurrent.Semaphore;
public class Attendant extends Thread {
	static Semaphore sem;
	static List<Integer>list;
	public Attendant(int total) {
		
	}
	
	//The yield() method of thread class causes the currently executing thread object to temporarily pause and allow other threads to execute.
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			Attendant.sem.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		msg("Attendent start calling");
		Passenger.zonesem[0].release();
		int len=Passenger.zonesem.length;
		try {
			Passenger.zonesem[len-1].acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		msg("All passenger are board, door is cloing right now");
		msg("Long Time sleeping");
		try {
			Thread.sleep(1500);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		msg("Arrive the destination");
		Passenger.passngersem[0].release();
	}
	
	
	
	public void msg(String m) {
		 System.out.println("["+(System.currentTimeMillis()-Main.time)+"] "+": "+m);
	}
}
